// JavaScript Document : Spire Media Inc.
///resize slider height
jQuery(document).ready(function(){

// click year make active

	$('a.xtrig').click(function() {
		$(this).parent().addClass('active');
		$(this).parent().siblings('.mnyBox').removeClass('active');
    return false;
  	});
	


//### Resize MAIN INDEX ###//
jQuery.event.add(window, "load", resizeMain);
jQuery.event.add(window, "resize", resizeMain);
function resizeMain() 
{
    var h = $(window).height();
    var w = $(window).width();
	//735+40+40
	if ( h > 934){
		//var newHeight = $(".mnNews").height();
		$("#mnMain").css('height',newHeight);
		//$("#mnMain").css('height',(h -119));
	}
	else {
		$("#mnMain").css('height',735);
	}
    
}

//**** UNIVERSAL NO EDITS***///
//### CONTACT SLIDER ###//	
	//Hide slider
	$('#sliderTop').hide();
	$('.tabLogo').click(function() {
    $('#sliderTop').slideToggle('slow');
	$('.default').dropkick();
    return false;
  	});
	
	$('.closeSlider').click(function() {
    $('#sliderTop').slideUp('slow');
    return false;
  	});

	//showcontact
	$('#contactSlide').hide().css({visibility: "visible"}).fadeIn(2000);

//### FOOTER SLIDER ###//	
	//Hide footer
	$('#foot').hide();
	function showFoot() {		
	$(this).children('#foot').slideToggle('slow');
	}			
	function hideFoot() {				
	$(this).children('#foot').slideToggle('medium');
	}
	
	$('#footer').hoverIntent({					
	sensitivity: 7, // number = sensitivity threshold (must be 1 or higher)
	interval: 300,   // number = milliseconds of polling interval (we don't need this as it is initiated on click rather than hover)
	over: showFoot,  // function = onMouseOver callback (required)
	timeout: 500,   // number = milliseconds delay before onMouseOut function call
	out: hideFoot   // function = onMouseOut callback (required)	
	})
		
});

jQuery(window).load(function() {
	jQuery('#loading-image').fadeOut('fast');
	
});
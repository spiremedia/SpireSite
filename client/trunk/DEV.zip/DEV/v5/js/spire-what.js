// JavaScript Document : Spire Media Inc.
jQuery(document).ready(function(){
 
//### FEATURED ROLLOVERS ###//	
	
	//Hide Rollovers
	$('.wwd0-on').hide();
	
$('#firstboxes li').hover(function(){
     $(this).removeClass('fade').siblings().addClass('fade');
},function(){
     $(this).siblings().andSelf().removeClass('fade');
})


	function showBox1() {	
		$(this).animate({ lineHeight: "282px"}, { duration: "fast" });
	}			
	function hideBox1() {
		//$(this).parent.children.css({ opacity:".5" });				
		$(this).animate({  lineHeight: "270px" }, { duration: "fast" });
	}
	
	$('.box1, .box2, .box3, .box4').hoverIntent({					
	sensitivity: 1, // number = sensitivity threshold (must be 1 or higher)
	interval: 0,   // number = milliseconds of polling interval (we don't need this as it is initiated on click rather than hover)
	over: showBox1,  // function = onMouseOver callback (required)
	timeout: 0,   // number = milliseconds delay before onMouseOut function call
	out: hideBox1   // function = onMouseOut callback (required)	
	})
	
		
//### Resize MAIN ###//
jQuery.event.add(window, "load", resizeMain);
jQuery.event.add(window, "resize", resizeMain);
function resizeMain() 
{
    var h = $(window).height();
    var w = $(window).width();
	
	if ( h > 800){
		$("#WWD").css('height',(h -119));
		//$("#mainWWD").css('margin-top',(-(h -119)));
		$("#mainWhat, .bg0, .bg1, .bg2, .bg3, .bg4").css('height',(h -119));
		//$("#wwd-0, #wwd-1, #wwd-2, #wwd-3, #wwd-4").css('height',(h -119 -45));
		//$("#sliderInfo").css('width',1026);
	}
	else {
		$("#WWD").css('height',671);
		//$("#mainWWD").css('margin-top',(-(671)));
		$("#mainWhat, .bg0, .bg1, .bg2, .bg3, .bg4").css('height',671);
		//$("#wwd-0, #wwd-1, #wwd-2, #wwd-3, #wwd-4").css('height',671 -45);
		//$("#sliderInfo").css('width',1006);
	}
	
	if ( w < 1398){
	var halfW = (w-758)/2;
	var halfW2 = (w-974)/2;
	
	var lastwidth = -(1398 - w);
		
		if (w > 1182 ){ $("#WWD").css('width', w); }
		 else { $("#WWD").css('width','1182px'); }
		
		
			 
		 if (halfW > 210 ){ $("#wwd-0").css('padding-left', halfW); }
		 else { $("#wwd-0").css('padding-left', '210px'); }
		 
		 if (halfW2 > 104 ){ $("#wwd-1, #wwd-2, #wwd-3, #wwd-4").css('padding-left', halfW2); }
		 else { $("#wwd-1, #wwd-2, #wwd-3, #wwd-4").css('padding-left', '104px'); }
		 
		//$("#main_wwd").css('margin-left', lastwidth); 
		//$("#sliderInfo").css('width',1026);
	}
	else {
		$("#WWD").css('width',w);
		
		$("#wwd-0").css('padding','45px 320px 0' );
		 $("#wwd-1, #wwd-2, #wwd-3, #wwd-4").css('padding', '45px 212px 0');
		 //$("#main_wwd").css('margin-left', 'auto'); 
		 
		 
		 
		 
	}
	
    
}
	

	
//**** UNIVERSAL NO EDITS***///
//### CONTACT SLIDER ###//	
	//Hide slider
	$('#sliderTop').hide();
	$('.tabLogo').click(function() {
    $('#sliderTop').slideToggle('slow');
	$('.default').dropkick();
    return false;
  	});
	
	$('.closeSlider').click(function() {
    $('#sliderTop').slideUp('slow');
    return false;
  	});

	//showcontact
	$('#contactSlide').hide().css({visibility: "visible"}).fadeIn(2000);

//### FOOTER SLIDER ###//	
	//Hide footer
	$('#foot').hide();
	function showFoot() {		
	$(this).children('#foot').slideToggle('slow');
	}			
	function hideFoot() {				
	$(this).children('#foot').slideToggle('medium');
	}
	
	$('#footer').hoverIntent({					
	sensitivity: 7, // number = sensitivity threshold (must be 1 or higher)
	interval: 300,   // number = milliseconds of polling interval (we don't need this as it is initiated on click rather than hover)
	over: showFoot,  // function = onMouseOver callback (required)
	timeout: 500,   // number = milliseconds delay before onMouseOut function call
	out: hideFoot   // function = onMouseOut callback (required)	
	})
		
});

jQuery(window).load(function() {
	jQuery('#loading-image').fadeOut('slow', function(){
     $('#slider1').delay(500).fadeIn('medium', goto);
    return false;
  });
  
  
function goto(){

		 if(window.location.hash === "#ux-design"){
	  setTimeout(function() { //alert('hello');
	$('.btn-uxd').trigger('click');
	  },1000);}
	  if(window.location.hash === "#visual-design"){
	  setTimeout(function() { 
	$('.btn-vd').trigger('click');
	  },1000); }
	  if(window.location.hash === "#web-development"){
	  setTimeout(function() { 
	$('.btn-wd').trigger('click');
	  },1000);}
	  if(window.location.hash === "#mobile-development"){
	  setTimeout(function() { 
	$('.btn-md').trigger('click');
	  },1000); }
}
	  
});

  $(document).ready(function(){

	var slider = $('#slider1').bxSlider({
    controls: false, infiniteLoop: false,
  });
  
  $('#slider1').hide();
//### SLIDER###//	
	$(".bx-window").css('overflow','visible');
	//$("#slider1").css('position', 'absolute');
	
	$('#go-prev').click(function(){
    slider.goToPreviousSlide();
    return false;
  });
  
  $('#go-next').click(function(){
    slider.goToNextSlide();
    return false;
  });	
  $('.btn-wwd').click(function(){
	$('.subnav li a').removeClass('active');
    slider.goToFirstSlide();
	$(this).live();
    return false;
  });
  
  $('.btn-uxd').click(function(){
	$('.subnav li a').removeClass('active');
	$('.subnav li .btn-uxd').addClass('active');slider.goToSlide(1);
	$(this).live();
    return false;
  });
  $('.btn-vd').click(function(){
	$('.subnav li a').removeClass('active');
	$('.subnav li .btn-vd').addClass('active');slider.goToSlide(2);
	$(this).live();
    return false;
  });
  $('.btn-wd').click(function(){
	$('.subnav li a').removeClass('active');
	$('.subnav li .btn-wd').addClass('active');slider.goToSlide(3);
	$(this).live();
    return false;
  });
  $('.btn-md').click(function(){
	$('.subnav li a').removeClass('active');
	$('.subnav li .btn-md').addClass('active');slider.goToSlide(4);
	$(this).live();
    return false;
  });
  
  });